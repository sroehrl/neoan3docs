<?php
// default route (homepage)
define('default_ctrl','demo');

// optional: custom 404
define('default_404','notFound');
