<?php


namespace Neoan3\Core;

use Exception;
use Throwable;

class RouteException extends Exception
{

}