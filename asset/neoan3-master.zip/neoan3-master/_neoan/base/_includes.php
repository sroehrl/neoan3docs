<?php
/*
 * Global
 * */
define('path', dirname(dirname(dirname(__FILE__))));
define('neoan_path', dirname(dirname(__FILE__)));
define('asset_path', dirname(dirname(dirname(__FILE__))) . '/asset');



include_once(neoan_path . '/base/functions.php');
include_once(neoan_path . '/base/loader.php');
